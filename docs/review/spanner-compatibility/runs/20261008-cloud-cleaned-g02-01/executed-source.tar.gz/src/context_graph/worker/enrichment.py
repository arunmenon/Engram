"""Consumer 3: Enrichment worker.

Reads events delivered by its subscription and enriches them with keywords
and importance scoring in the graph. Future phases will add embedding
computation, SIMILAR_TO edge creation, and entity extraction for REFERENCES edges.

Source: ADR-0008 (Stage 2), ADR-0013 (Consumer 3)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import structlog

from context_graph.worker.consumer import BaseConsumer

if TYPE_CHECKING:
    from context_graph.ports.embedding import EmbeddingService
    from context_graph.ports.event_log import EventLog
    from context_graph.ports.graph_store import GraphStore
    from context_graph.ports.subscription import Subscription
    from context_graph.settings import Settings

log = structlog.get_logger(__name__)

DEFAULT_IMPORTANCE = 5


class EnrichmentConsumer(BaseConsumer):
    """Consumer 3: Enriches events with keywords and importance scoring.

    For each event received from the subscription:
    1. Fetch the event document from the event log.
    2. Extract keywords from the event_type (split by '.') and tool_name.
    3. Determine importance_score from importance_hint or use default.
    4. Update the Neo4j node with keywords and importance_score.
    """

    def __init__(
        self,
        subscription: Subscription,
        event_log: EventLog,
        graph_store: GraphStore,
        settings: Settings,
        embedding_service: EmbeddingService | None = None,
    ) -> None:
        super().__init__(
            subscription,
            block_timeout_ms=settings.consumer.block_timeout_ms,
            max_retries=settings.consumer.max_retries,
        )
        self._event_log = event_log
        self._graph_store = graph_store
        self._embedding_service = embedding_service

    async def process_message(self, entry_id: str, data: dict[str, str]) -> None:
        """Process a single delivery: extract keywords and update the graph."""
        event_id = data.get("event_id")
        if event_id is None:
            log.warning("enrichment_missing_event_id", entry_id=entry_id)
            return

        # Fetch the full event document from the event log
        documents = await self._event_log.get_documents([event_id])
        doc = documents[0]
        if doc is None:
            log.warning(
                "enrichment_event_json_not_found",
                event_id=event_id,
                entry_id=entry_id,
            )
            return

        # Extract keywords from event_type
        event_type = doc.get("event_type", "")
        keywords = extract_keywords(event_type, doc.get("tool_name"))

        # Determine importance score
        importance_hint = doc.get("importance_hint")
        importance_score = importance_hint if importance_hint is not None else DEFAULT_IMPORTANCE

        # Update Neo4j node
        await self._graph_store.update_event_enrichment(event_id, keywords, importance_score)

        log.debug(
            "event_enriched",
            event_id=event_id,
            keywords=keywords,
            importance_score=importance_score,
        )

        # Compute and store event embedding on Neo4j node
        await self._compute_and_store_event_embedding(event_id, event_type, doc)

    async def _compute_and_store_event_embedding(
        self,
        event_id: str,
        event_type: str,
        doc: dict[str, Any],
    ) -> None:
        """Compute embedding for an event and store it on the Neo4j node.

        Gracefully degrades: if embedding_service is None or raises, the
        event is still enriched with keywords and importance — just no embedding.
        """
        if self._embedding_service is None:
            return

        tool_name = doc.get("tool_name")
        keywords = extract_keywords(event_type, tool_name)
        text = build_event_text(event_type, tool_name, keywords)

        try:
            embedding = await self._embedding_service.embed_text(text)
        except Exception:
            log.warning("event_embedding_failed", event_id=event_id)
            return

        await self._graph_store.store_event_embedding(event_id, embedding)
        log.debug("event_embedding_stored", event_id=event_id)


def build_event_text(event_type: str, tool_name: str | None, keywords: list[str]) -> str:
    """Build a text representation of an event for embedding.

    Format: "{event_type} {tool_name} {keywords}"
    """
    parts = [event_type]
    if tool_name:
        parts.append(tool_name)
    parts.extend(k for k in keywords if k not in parts)
    return " ".join(parts)


def extract_keywords(event_type: str, tool_name: str | None = None) -> list[str]:
    """Extract keywords from an event_type string and optional tool_name.

    Splits event_type by '.' to get component parts, and adds tool_name
    if present and not already included.
    """
    keywords = [part for part in event_type.split(".") if part]
    if tool_name and tool_name not in keywords:
        keywords.append(tool_name)
    return keywords
