"""Filesystem archive adapter package."""
